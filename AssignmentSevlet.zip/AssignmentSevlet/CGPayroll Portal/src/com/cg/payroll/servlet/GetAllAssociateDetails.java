package com.cg.payroll.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.payrollServices;
import com.cg.payroll.services.PayrollServiceImpl;


@WebServlet("/allAssociateDetails")
public class GetAllAssociateDetails extends HttpServlet {
	private payrollServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void init() throws ServletException
	{
		services=new PayrollServiceImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		List<Associate> associates=new ArrayList<Associate>();
		associates=services.getAllAssociateDetails();
		request.setAttribute("associate", associates);
		request.getRequestDispatcher("allAssociateDetails.jsp").forward(request, response);	
	}
	@Override
	public void destroy() 
	{
		services=null;
	}
}