package com.cg.payroll.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailNotFoundException;
import com.cg.payroll.services.payrollServices;
import com.cg.payroll.services.PayrollServiceImpl;


@WebServlet("/associateDetails")
public class GetAssociateDetails extends HttpServlet {
	private payrollServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void init() throws ServletException
	{
		services=new PayrollServiceImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int associateId=Integer.parseInt(request.getParameter("associateId"));

		Associate associate=null;
		try
		{
			associate=services.getAssociateDetails(associateId);
			request.setAttribute("associate", associate);
			request.getRequestDispatcher("associateDetailssuccess.jsp").forward(request, response);	
		}catch (AssociateDetailNotFoundException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("associateDetailserror.jsp").forward(request, response);	
		}

		
	}
	@Override
	public void destroy() 
	{
		services=null;
	}
}