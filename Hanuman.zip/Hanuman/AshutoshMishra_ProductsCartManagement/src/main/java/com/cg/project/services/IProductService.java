package com.cg.project.services;

import java.util.List;

import com.cg.project.beans.Product;
import com.cg.project.exceptions.ProductDetailsNotFoundException;


public interface IProductService {
	Product acceptProductDetails(Product product); //creating Product
	Product getProductDetails(String id) throws ProductDetailsNotFoundException; //Find Product using given ProductId
	 List<Product>getAllProductDetails(); //View all product Details
	 boolean removeProductDetails(String id) throws ProductDetailsNotFoundException; //Delete Product for given productId
	 Product updateProductDetails(Product product);//updating product
}
