package com.cg.project.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.project.exceptions.ProductDetailsNotFoundException;
import com.cg.project.response.CustomeResponse;

@ControllerAdvice
public class ProductExceptionAspect {
	@ExceptionHandler(ProductDetailsNotFoundException.class)
	  public ResponseEntity<CustomeResponse> handleProductDetailsNotFoundException(Exception e) {
	     
		  CustomeResponse response = new CustomeResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		  return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	  }
}
