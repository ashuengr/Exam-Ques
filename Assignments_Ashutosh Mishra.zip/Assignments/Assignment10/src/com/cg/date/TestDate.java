package com.cg.date;
import org.junit.Test;
import junit.framework.Assert;

public class TestDate {
	@Test
	public void testGetDay()
	{
		System.out.println("from dateTest");
		Date per = new Date(03,07,2017);
		Assert.assertEquals(03,per.getDay());
	}
	@Test
	public void testGetMonth(){
		System.out.println("from dateTest");
		Date per = new Date(03,07,2017);
		Assert.assertEquals(07,per.getMonth());
	}
	@Test
	public void testGetYear(){
		System.out.println("from dateTest");
		Date per = new Date(03,07,2017);
		Assert.assertEquals(2017,per.getYear());
	}
	@Test
	public void testToString()
	{
		System.out.println("from dateTest");
		Date per = new Date(03,07,2017);
		Assert.assertEquals("Date is 03/07/2017",per.toString());
	}
}
