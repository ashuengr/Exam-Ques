package com.cg.person;
import org.junit.Assert;
import org.junit.Test;
public class TestPerson {
	@Test
	public void testGetFirstName(){
		Person per = new Person("ASHUTOSH","MISHRA", 'M');
		Assert.assertEquals("ASHUTOSH",per.getFirstName());
	}
	@Test
	public void testGetLastName(){
		Person per = new Person("ASHUTOSH","MISHRA", 'M');
		Assert.assertEquals("MISHRA",per.getLastName());
	}
	@Test
	public void testGetGender(){
		Person per = new Person("ASHUTOSH","MISHRA",'M');
		Assert.assertEquals('M',per.getGender());
	}
	public void testToString(){
		Person per = new Person("ASHUTOSH","MISHRA",'M');
		Assert.assertEquals("Person [firstName= ASHUTOSH , lastName= MISHRA , gender= M ]",per.toString());
	}
}


