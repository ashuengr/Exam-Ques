package com.cg.person;
public class MainClass {
	public static void main(String...args)
	{   
		Person person = new Person();
		person.setFirstName("Ashish");
		person.setLastName("Mishra");
		person.setGender('M');
		String name = person.getFirstName();
		String last = person.getLastName();
		char gender = person.getGender();
		Person person2 = new Person(name,last,gender);
		System.out.println(person2.toString());
	}
}