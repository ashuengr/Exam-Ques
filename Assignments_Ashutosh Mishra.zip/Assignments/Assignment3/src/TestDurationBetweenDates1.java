import java.util.Scanner;
public class TestDurationBetweenDates1
{

 public static void main(String arg[])
 {
   	Scanner obj=new Scanner(System.in);
   	System.out.println("Enter day of year1:");
   	int day1=obj.nextInt();
   	System.out.println("Enter month of year1:");
   	int month1=obj.nextInt();
   	System.out.println("Enter year1:");
   	int year1=obj.nextInt();
   	DurationBetweenDates1 obj1=new DurationBetweenDates1();
   	obj1.displayDuration(day1, month1, year1);
   	
 }
}

