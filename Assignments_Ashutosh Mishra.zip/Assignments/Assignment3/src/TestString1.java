import java.util.Scanner;
public class TestString1
{
 public static void main(String ar[])
 {
	Scanner obj=new Scanner(System.in);
	CheckString obj1=new CheckString();
	System.out.println("Enter the String:");
	String str=obj.nextLine();
	if(obj1.CheckString(str))
		System.out.println("Positive  string");
	else
		System.out.println("negative string");
 }
}
