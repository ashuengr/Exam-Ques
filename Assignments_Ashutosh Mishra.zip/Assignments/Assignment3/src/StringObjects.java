import java.util.Arrays;
import java.util.Scanner;
public class StringObjects
{
 public static void main(String ar[])
 {
	 Scanner obj = new Scanner(System.in);
	 System.out.println("enter the no of strings to be entered:");
	 int strCount=obj.nextInt();
	 String strobj[]=new String[strCount];
	 System.out.println("Enter string objects:");
	 for(int i=0;i<strCount;i++)
	 {
		 strobj[i]=obj.next();
	 }
	 Arrays.sort(strobj);
	 int range;
	 if(strCount%2==1)
	 {
		 range=strCount/2+1;
	 }
	 else range=strCount/2;
	 for(int i=0;i<range;i++)
	 {
		 strobj[i]=strobj[i].toUpperCase();
	 }
	 System.out.println("String objects after sorting are:");
	 for(int i=0;i<strCount;i++)
	 {
		 System.out.println(strobj[i]);
	 }
 }
	 
 
}
