import java.time.LocalDate;
import java.time.Period;


public class DurationBetweenDates 
{
  int year1;
  int month1;
  int day1;
  int year2;
  int month2;
  int day2;
  public void displayDuration(int day1,int month1,int year1,int day2,int month2,int year2)
  {
    LocalDate date1=LocalDate.of(year1, month1,day1 );
    LocalDate date2=LocalDate.of(year2, month2, day2);
    Period duration=Period.between(date1, date2);
    System.out.println("The duration between two dates given by user is:"+duration.getDays()+"days"+duration.getMonths()+"months"+duration.getYears()+"years");
    				
  }
}
