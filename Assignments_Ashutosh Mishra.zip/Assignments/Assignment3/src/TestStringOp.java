import java.util.Scanner;
public class TestStringOp 
{
 public static void main(String ar[])
 {
	 Scanner obj=new Scanner(System.in);
	 Stringop obj1=new Stringop();
	 System.out.println("Enter the string");
	 String str=obj.nextLine();
	 String str1,str2,str3,str4;
	 str1=obj1.addItself(str);
	 str2=obj1.replaceOdd(str);
	 str3=obj1.removeDuplicate(str);
	 str4=obj1.oddUppercase(str);
	 System.out.println("String after adding itself is:"+str1);
	 System.out.println("String after epacing odd character with #  is:"+str2);
	 System.out.println("String after removing duplicate character is:"+str3);
	 System.out.println("String after converting odd places to uppercase is:"+str4);
 }
}
