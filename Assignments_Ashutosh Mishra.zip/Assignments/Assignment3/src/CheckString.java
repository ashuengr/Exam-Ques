import java.util.Arrays;
public class CheckString 
{
 public static boolean CheckString(String str)
 {
	 char arr[]=str.toCharArray();
	 char sortedArray[]=str.toCharArray();
	 Arrays.sort(sortedArray);
	 for(int i=0;i<sortedArray.length;i++)
	 {
	   if(arr[i]!=sortedArray[i])
		   return false;
	 }
	 return true;
 }
}
