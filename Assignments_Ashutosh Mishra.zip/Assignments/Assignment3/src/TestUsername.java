import java.util.Scanner;
public class TestUsername 
{
 public static void main(String ar[])
 {
	 Scanner obj1=new Scanner(System.in);
	 Username obj2=new Username();
	 System.out.println("Enter the Username: ");
	 String str=obj1.nextLine();
	 if(obj2.checkEnd(str)&&(obj2.checkLength(str)))
		 System.out.println("correct Username");
	 else
		 System.out.println("Incorrect Username");
 }
}
