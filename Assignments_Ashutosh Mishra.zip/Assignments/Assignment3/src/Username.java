
public class Username 
{
 public static boolean checkEnd(String str)
 {
	 char arr[]=str.toCharArray();
	 int length=arr.length;
	 if((arr[length-1]=='b')&&(arr[length-2]=='o')&&(arr[length-3]=='j')&&(arr[length-4]=='_'))
       return true;
     else
       return false;	   
  }
 public static boolean checkLength(String str)
 {
	 int length=str.length();
	 if(length>=12)
		 return true;
	 else
		 return false;
 }
}
