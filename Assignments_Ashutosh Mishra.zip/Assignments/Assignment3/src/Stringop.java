
public class Stringop
{
 public String addItself(String str1)
 {
	 String newstr;
	 newstr=str1+str1;
	 return newstr;
 }
 public String replaceOdd(String str1)
 {
	 int j;
	 char arr[]=str1.toCharArray();
	 for(j=0;j<arr.length;j=j+2)
	 {
		 arr[j]='#';
	 }
	 String newstr= new String(arr);
	 return newstr;
 }
 public String removeDuplicate(String str1)
 {
	 int i,j,k,temp;
	 char arr1[]=str1.toCharArray();
	 int length=arr1.length;
	 for(i=0;i<length;i++)
	 {
		 for(j=i+1;j<length;j++)
		 {
			 if(arr1[i]==arr1[j])
			 {
				 temp=j;
				 for(k=temp;k<length-1;k++)
				 {
					 arr1[k]=arr1[k+1];
				 }
				 j--;
				 length--;
			 }
		 }
	 }
	 String newstr=new String(arr1);
	 newstr=newstr.substring(0,length);
	 return newstr;
 }
 public String oddUppercase(String str1)
 {
	 char arr[]=str1.toCharArray();
	 for(int i=0;i<arr.length;i=i+2)
	 {
		 arr[i]=Character.toUpperCase(arr[i]);
	 }
	String newstr=new String(arr);
	return newstr;
 }
}
