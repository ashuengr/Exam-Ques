import java.time.LocalDate;
import java.time.Period;


public class DurationBetweenDates1 
{
	int year1;
	int month1;
	int day1;
	public void displayDuration(int day1,int month1,int year1)
	{
		LocalDate date1=LocalDate.of(year1, month1,day1 );
		LocalDate date2=LocalDate.now();
		Period duration=Period.between(date1, date2);
	    System.out.println("The duration between entered date and current date is:"+duration.getDays()+"days "+duration.getMonths()+" months "+duration.getYears()+" years");
	    				
	}
}

