import java.util.*;
public class TestDurationBetweenDates
{

 public static void main(String arg[])
 {
   	Scanner obj=new Scanner(System.in);
   	System.out.println("Enter day of year1:");
   	int day1=obj.nextInt();
   	System.out.println("Enter month of year1:");
   	int month1=obj.nextInt();
   	System.out.println("Enter year1:");
   	int year1=obj.nextInt();
   	System.out.println("Enter day of year2:");
   	int day2=obj.nextInt();
   	System.out.println("Enter month of year2:");
   	int month2=obj.nextInt();
   	System.out.println("Enter year2:");
   	int year2=obj.nextInt();
   	DurationBetweenDates obj1=new DurationBetweenDates();
   	obj1.displayDuration(day1, month1, year1, day2, month2, year2);
   	
 }
}