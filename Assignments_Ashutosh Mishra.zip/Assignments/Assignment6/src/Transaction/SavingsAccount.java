package Transaction;
public class SavingsAccount extends Account
{
	double minBalance;
	public double getMinBalance() 
	{
		return minBalance;
	}
	public void setMinBalance(double minBalance) 
	{
		this.minBalance = minBalance;
	}
	public void withdraw(double amount)
	{
		if(amount>balance)
		{
			System.out.println("Not Sufficient balance in Account");
		}
		else if(balance - amount<minBalance)
		{
			System.out.println("Transaction Unsuccessful due to Low Balance");
		}
		else 
		{
			balance  = balance - amount;
			System.out.println("Transaction Successful and remaining Balance : "+ balance);
		}
	}
}
