package PersonValidation;
import java.util.Scanner;
public class Person 
{
	String firstName;
	String lastName;
	PersonGender gender;
	int age;
	double weight;
	long contact;
	Person()
	{
		firstName=null;
		lastName=null;
		gender=PersonGender.U;
		age=0;
		weight=0;
		contact=0;
	}
	Person(String fname, String lname, PersonGender gender, int age, double weight, long contact)
	{
		this.firstName=fname;
		this.lastName = lname;
		this.gender=gender;
		this.age = age;
		this.weight = weight;
		this.contact = contact;
	}
	String getFname()
	{
		return firstName;
	}
	void setFname(String fn) 
	{
		if(fn=="")
		{
			try
			{
				throw new EmptyNameException();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("First Name Empty.");
			}
		}
		else{
				firstName = fn;
			}
	}
	String getLname()
	{
		return lastName;
	}
	void setLname(String ln)
	{
		if(ln=="")
		{
			try
			{
				throw new EmptyNameException();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Last Name Empty.");
			}
		}
		else
		{
			lastName = ln;
		}
	}
	PersonGender getGender()
	{
		return gender;
	}
	void setGender(PersonGender gn)
	{
		gender = gn;
	}
	int getAge()
	{
		return age;
	}
	void setAge(int ag)
	{
		age = ag;
	}
	double getWeight()
	{
		return weight;
	}
	void setWeight(double wt)
	{
		weight = wt;
	}
	long getContact()
	{
		return contact;
	}
	void setContact(long cont)
	{
		contact = cont;
	}
	public void setDetails()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Fill Person Details:");
		System.out.println("_____________________");
		System.out.println("First Name : ");
		setFname(sc.next());
		System.out.println("Last Name : ");
		setLname(sc.next());
		System.out.println("Gender : 1: Male   2: Female");
		int index = sc.nextInt();
		switch(index)
		{
			case 1:
				setGender(PersonGender.M);
			default : 
				setGender(PersonGender.F);
		}		
		System.out.println("Age : ");
		setAge(sc.nextInt());
		System.out.println("Weight : ");
		setWeight(sc.nextDouble());
		System.out.println("Contact : ");
		setContact(sc.nextLong());
	}
	
	public void getDetails()
	{
		System.out.println("Person Details:");
		System.out.println("_____________________");
		System.out.println("First Name : "+ getFname());
		System.out.println("Last Name : "+ getLname());
		System.out.println("Gender : "+ getGender());
		System.out.println("Age : "+ getAge());
		System.out.println("Weight : "+ getWeight());
		System.out.println("Contact : "+ getContact());
	}
}
