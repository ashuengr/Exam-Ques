package com.cg.eis.beans;
public class Employee 
{
	private int empId;
	String empName;
	double empSalary;
	Designations designation;
	InsuranceSchemes insuranceSchemes=null;
	public Employee(int id, String name,double salary, Designations designation,
			InsuranceSchemes insuranceSchemes) {
		super();
		this.empId = id;
		this.empName = name;
		this.empSalary = salary;
		this.designation = designation;
		this.insuranceSchemes = insuranceSchemes;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + empId;
		result = prime * result + ((insuranceSchemes == null) ? 0 : insuranceSchemes.hashCode());
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(empSalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (designation != other.designation)
			return false;
		if (empId != other.empId)
			return false;
		if (insuranceSchemes != other.insuranceSchemes)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (Double.doubleToLongBits(empSalary) != Double.doubleToLongBits(other.empSalary))
			return false;
		return true;
	}
	public int getId() {
		return empId;
	}
	public void setId(int id) {
		this.empId = id;
	}
	public String getName() {
		return empName;
	}
	public void setName(String name) {
		this.empName = name;
	}
	public double getSalary() {
		return empSalary;
	}
	public void setSalary(double salary) {
		this.empSalary = salary;
	}
	public Designations getDesignation() {
		return designation;
	}
	public void setDesignation(Designations designation) {
		this.designation = designation;
	}
	public InsuranceSchemes getInsuranceSchemes() {
		return insuranceSchemes;
	}
	public void setInsuranceSchemes(InsuranceSchemes insuranceSchemes) {
		this.insuranceSchemes = insuranceSchemes;
	}
	@Override
	public String toString() {
		return "Employee [id=" + empId + ", name=" + empName + ", salary=" + empSalary
				+ ", designation=" + designation + ", insuranceSchemes="
				+ insuranceSchemes + "]";
	}
}
