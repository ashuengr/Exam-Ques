package com.cg.eis.beans;
public enum Designations 
{
	Analyst,Programmer,Manager,Clerk;
}

