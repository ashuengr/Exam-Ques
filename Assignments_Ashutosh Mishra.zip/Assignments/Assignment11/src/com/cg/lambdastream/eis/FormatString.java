package com.cg.lambdastream.eis;
@FunctionalInterface
public interface FormatString {
	public String formatString(String s);
}
