package com.cg.lambdastream.eis;
@FunctionalInterface
public interface PowerFunction {
	public double power(double  x,double  y);

}
