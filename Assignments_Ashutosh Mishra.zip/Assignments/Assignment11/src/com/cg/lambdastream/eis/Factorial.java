package com.cg.lambdastream.eis;
@FunctionalInterface
public interface Factorial {
	public long fact(int num);
}
