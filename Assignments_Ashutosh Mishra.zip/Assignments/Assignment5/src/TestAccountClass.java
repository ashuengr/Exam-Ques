
public class TestAccountClass
{
public static void main(String ar[])
{
	TestAccount Smith=new TestAccount();
	Person pp =new Person();
	pp.setName("Smith");
	pp.setAge(20);
	Smith.setBalance(2000);
	//Smith.setAccNo(123);
	Smith.setAccHolder(pp);
	
	TestAccount Kathy=new TestAccount();
	Person pp1 = new Person();
	pp1.setName("Kathy");
	pp1.setAge(22);
	Kathy.setBalance(3000);
	Kathy.setAccHolder(pp1);
	//Smith.setAccNo(456);
	
	Smith.deposit(2000);
	System.out.println("Smith balance is:"+Smith.getBalance());
	Kathy.withdraw(2000);
	System.out.println("kathy balance is:"+Kathy.getBalance());	
}
}
