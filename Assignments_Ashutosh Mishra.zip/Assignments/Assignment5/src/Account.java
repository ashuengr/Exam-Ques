
public abstract class Account 
{
 long accNo;
 double balance;
 static int count=1;
 Person accHolder;
 
 public abstract void withdraw(double amount);
 public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public long getAccno()
 {
  return accNo;
 }
 public double getBalance()
 {
	 return balance;
 }
 
 
 public void setAccNo()
 {
	 this.accNo=count;
	 count++;
 }
 public void setBalance(double balance)
 {
	 this.balance=balance;
 }
 public void deposit(double amount)
 { 
	balance=balance+amount; 
 }
 }

