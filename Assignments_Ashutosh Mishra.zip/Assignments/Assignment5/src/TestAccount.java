
public class TestAccount extends Account
{
 public TestAccount()
 {
	 
 }
 public void withdraw(double amount)
 {
    if(amount>balance)
   {
    System.out.println("Insufficient Balance");
   }
	else if(balance-amount<500)
	 {
		 System.out.println("Transaction unsuccessful due to Insufficient Balance"); 
	 }
	 else
	 {
		 balance=balance-amount;
		 System.out.println("Transaction successful and available balance:"+balance);
	 }
 }
}
