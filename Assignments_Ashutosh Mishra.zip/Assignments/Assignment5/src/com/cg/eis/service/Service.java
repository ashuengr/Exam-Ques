package com.cg.eis.service;
import com.cg.eis.bean.*;
public class Service implements EmployeeService
{
 String empInsSch;

@Override
public void empServices(long empSal, String empDesg)
{
 if((empSal)<5000 && (empDesg).equals("Clerk"))	
	 empInsSch="Null";
 
 else if(((empSal)>5000) &&(empSal <2000) && (empDesg).equals("System Analyst"))	
	 empInsSch="Scheme C";
 else if(((empSal)>20000) &&(empSal)<40000 && (empDesg).equals("Consultant"))	
			 empInsSch="Scheme B";
 else if(((empSal)>=40000)  && (empDesg).equals("Manager"))	
		 empInsSch="Scheme A";
 else
	 empInsSch="Null";
	
}
public String dispEmpInfo()
{
return "Employee Insurance Scheme"+empInsSch;
}
 
}
