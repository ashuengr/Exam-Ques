package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;
public class TestEmployee 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter your Emp Id:");
		 int empId=sc.nextInt();
		 System.out.println("Enter your Emp Name:");
		 String empName=sc.next();
		 System.out.println("Enter your Salary:");
		 long empSal=sc.nextInt();
		 System.out.println("Enter employee designation:");
		 String empDesg=sc.next();
		 
		 Employee emp=new Employee(empId,empName,empSal,empDesg);
		 Service ser=new Service();
		 ser.empServices(empSal,empDesg);
		 System.out.println(emp.dispEmpInfo());
		 System.out.println(ser.dispEmpInfo());
		 
	}
}
