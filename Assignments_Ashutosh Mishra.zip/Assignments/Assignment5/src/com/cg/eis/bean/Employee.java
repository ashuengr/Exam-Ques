package com.cg.eis.bean;

public class Employee 
{
 int empId;
 String empname;
 long empSal;
 String empDesignation;
public Employee(int empId, String empname, long empSal, String empDesignation) {
	super();
	this.empId = empId;
	this.empname = empname;
	this.empSal = empSal;
	this.empDesignation = empDesignation;
}
public String dispEmpInfo() 
{
	return "Employee [empId=" + empId + ", empname=" + empname + ", empSal="
			+ empSal + ", empDesignation=" + empDesignation + "]";
}
}
