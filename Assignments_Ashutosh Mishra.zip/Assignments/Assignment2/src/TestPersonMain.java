
public class TestPersonMain 
{
	public static void main(String args[])
	{
		PersonMain person1 = new PersonMain();
		PersonMain person2 = new PersonMain("Akash " , " Mishra " , 'M',1234567890);
		person1.PersonDisplay();
		person2.PersonDisplay();
		
	}
}
