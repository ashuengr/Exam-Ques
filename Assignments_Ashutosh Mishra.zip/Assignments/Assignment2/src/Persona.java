
public class Persona 
{
 private String firstName;
 private String lastName;
 private char gender;
 public String getPersonFirstName()
 {
	 return firstName;
 }
 public String getPersonLastName()
 {
	 return lastName;
 }
 public char getPersonGender()
 {
	 return gender;
 }
 public void setPersonFirstName(String firstName)
 {
	 this.firstName=firstName;
 }
 public void setPersonLastName(String lastName)
 {
	 this.lastName=lastName;
 }
 public void setPersonGender(char gender)
 {
	 this.gender=gender;
 }
}
