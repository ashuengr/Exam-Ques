
public class Person 
{
 public static void main(String arg[])
 {
	 String firstname="Divya";
	 String lastname="Bharathi";
	 char gender='F';
	 int age=20;
	 double weight=85.55;
	 System.out.println("Person Details");
	 System.out.println("_______________");
	 System.out.println("FirstName:"+firstname);
	 System.out.println("lastName:"+lastname);
	 System.out.println("Gender:"+gender);
	 System.out.println("Age:"+age);
	 System.out.println("Weight:"+weight);
	 
 }
}
