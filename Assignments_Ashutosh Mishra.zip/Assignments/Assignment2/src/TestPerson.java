
public class TestPerson
{
 public static void main(String args[])
 {
	 Persona ashu=new Persona();
	 ashu.setPersonFirstName("Ashutosh");
	 ashu.setPersonLastName("Mishra");
	 ashu.setPersonGender('M');
	 System.out.println("First Name:"+ashu.getPersonFirstName());
	 System.out.println("Last Name:"+ashu.getPersonLastName());
	 System.out.println("Gender is:"+ashu.getPersonGender());
	 
 }
}
