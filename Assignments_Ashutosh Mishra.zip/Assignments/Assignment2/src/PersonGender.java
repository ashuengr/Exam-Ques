
public enum PersonGender 
{
 M,F;
}
