
public class PersonMain 
{
	String firstName;
	String lastName;
	char gender;
	int phoneno;
	public PersonMain()
	{
		firstName=null;
		lastName=null;
		gender=' ';
		phoneno=0;
	}
	public PersonMain(String FirstName,String LastName,char Gender,int no)
	{
		firstName=FirstName;
		lastName=LastName;
		gender=Gender;
		phoneno=no;
	}
	public void PersonDisplay()
	{
		System.out.println("FirstName:"+firstName);
		System.out.println("lastName:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("Phoneno:"+phoneno);
	}
}
