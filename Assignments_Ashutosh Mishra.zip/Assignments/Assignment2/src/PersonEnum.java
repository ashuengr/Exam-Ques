
public class PersonEnum 
{
		String firstName;
		String lastName;
		PersonGender gender;
		int phoneno;
		public PersonEnum()
		{
			firstName=null;
			lastName=null;
			gender=PersonGender.M;
			phoneno=0;
		}
		public PersonEnum(String FirstName,String LastName,PersonGender Gender,int no)
		{
			firstName=FirstName;
			lastName=LastName;
			gender=Gender;
			phoneno=no;
		}
		public void PersonDisplay()
		{
			System.out.println("FirstName:"+firstName);
			System.out.println("lastName:"+lastName);
			System.out.println("Gender:"+gender);
			System.out.println("Phoneno:"+phoneno);
	    }
	

}
