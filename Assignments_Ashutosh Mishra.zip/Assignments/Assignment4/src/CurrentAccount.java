
public class CurrentAccount extends Account
{
 double overdraftLimit;
 public double getOverDraftLimit()
 {
	 return overdraftLimit;
 }
 public void setOverdraftLimit(double overdraftLimit)
 {
	 this.overdraftLimit=overdraftLimit;
 }
 public void withdraw(double amount)
 {
	 boolean status;
	 status=checkOverdraft(amount);
	 
	 if(status==true)
	 {balance =balance-amount;
	 System.out.println("Transaction successful and available balance:"+balance);
	 }
 }
 public boolean checkOverdraft(double amount)
 {
	 boolean status;
	 if(amount>overdraftLimit)
	 {
		 System.out.println("Insufficient Balance");
		 status=false;
	 }
	 else if(balance-amount<overdraftLimit)
	 {
		 System.out.println("Transaction unsuccessful due to Insufficient Balance"); 
		 status=false;
	 }
	 else
	 {
		 balance=balance-amount;
		 System.out.println("Transaction successful and available balance:"+balance);
		 status=true;
	 }
	 return status;
 }
}
