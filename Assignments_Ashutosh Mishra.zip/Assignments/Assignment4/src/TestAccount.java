
public class TestAccount 
{
	public static void main(String ar[])
	 {
		Account Smith=new Account();
		Person pp =new Person();
		pp.setName("Smith");
		pp.setAge(20);
		Smith.setBalance(2000);
		//Smith.setAccNo(123);
		Smith.setAccHolder(pp);
		
		Account Kathy=new Account();
		Person pp1 = new Person();
		pp1.setName("Kathy");
		pp1.setAge(22);
		Kathy.setBalance(3000);
		Kathy.setAccHolder(pp1);
		//Smith.setAccNo(456);
		
		Smith.deposit(2000);
		System.out.println("Smith balance is:"+Smith.getBalance());
		Kathy.withdraw(2000);
		System.out.println("kathy balance is:"+Kathy.getBalance());
		
		SavingsAccount obj1=new SavingsAccount();
		obj1.setMinBalance(500);
		obj1.setBalance(550);
		obj1.withdraw(500);

		CurrentAccount obj2=new CurrentAccount();
		obj2.setOverdraftLimit(500);
		obj2.setBalance(550);
		obj2.withdraw(500);

		
	 }
}
