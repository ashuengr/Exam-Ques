
public class Account 
{
 long accNo;
 double balance;
 static int count=1;
 Person accHolder;
 
 public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public long getAccno()
 {
  return accNo;
 }
 public double getBalance()
 {
	 return balance;
 }
 
 
 public void setAccNo(long accNo)
 {
	 this.accNo=count;
	 count++;
 }
 public void setBalance(double balance)
 {
	 this.balance=balance;
 }
 public void deposit(double amount)
 { 
	balance=balance+amount; 
 }
 public void withdraw(double amount)
 {
    if(amount>balance)
   {
    System.out.println("Insufficient Balance");
   }
	else if(balance-amount<500)
	 {
		 System.out.println("Transaction unsuccessful due to Insufficient Balance"); 
	 }
	 else
	 {
		 balance=balance-amount;
		 System.out.println("Transaction successful and available balance:"+balance);
	 }
 }
}
